/*
Date: 03/04/19
Author(s):Sampath Talluri
Class:CS5541
Assignment:Cache simulator
*/
/*
References:
Slide reference
http://stackoverflow.com/questions/23092307/cache-simulator
https://github.com/theycallmeswift/Direct-Mapped-Cache-Simulation/blob/master/src/sim.c
https://www.youtube.com/watch?v=BidkO8kqQts
http://www.cs.wm.edu/~liqun/teaching/cs304/cs304_15f/labs/cachelab.html
https://github.com/theycallmeswift/Direct-Mapped-Cache-Simulation/blob/master/src/sim.c
*/

#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <strings.h>
#include <limits.h>
#include <assert.h>


//we will be  Always use a 64-bit variable for holding the memory
typedef unsigned long long int memory_address_t;

void printSummary(int hits,  //counts  no of  hits 
                  int misses, //count no of misses 
                  int evictions); //count no of evictions

// creating a structure for cache
typedef struct
{
   int s;                       // cache set for 2**s
   int b;                       // chache bytes int s; 
   int E;                       // count no:of cachelines per set */
   int S;                       // number of sets from S = 2**s cache
   int B;                       // block size (bytes) s=2**s
} cache_paramater_t;

int verbosity;


void printSummary( int hits, int misses, int evictions )   // calling the function
{
   printf("hits:%d misses:%d evictions:%d\n", hits, misses, evictions); // gives the number of the hits and misses and eviction
    FILE* output_fp = fopen(".csim_results", "w");   // writing into a file
    assert(output_fp);
    fprintf(output_fp, "%d %d %d\n", hits, misses, evictions);
    fclose(output_fp);					//closing the file
} 
// main function is here
int main( int argc, char **argv )
{
   cache_paramater_t par;

   bzero( &par, sizeof ( par ) );

   char *trace_file;
   char c;

   while ( ( c = getopt( argc, argv, "s:E:b:t:vh" ) ) != -1 )  // trace the file here
   {
      switch ( c )
      {
         case 's':
            par.s = atoi( optarg );
            break;
         case 'E':
            par.E = atoi( optarg );
            break;
         case 'b':
            par.b = atoi( optarg );
            break;
         case 't':
            trace_file = optarg;
            break;
         case 'v':
            verbosity = 1;
            break;
         case 'h':
 
            exit( 0 );
         default:
        
            exit( 1 );
      }
   }

   if ( par.s == 0 || par.E == 0 || par.b == 0 || trace_file == NULL )   // checks for the trace/yi.trace
   {
      printf( "%s: Missing required command line argument\n", argv[0] ); // if the trace file is not found its prints this statement
    
      exit( 1 );
   }

   

   //Compute S and B, 2^s and cache set and block size 
   par.S = ( 1 << par.s );     // cache set
   par.B = ( 1 << par.b );   // block size

   // Initialize a cache here

   
   typedef struct
   {
      int valid;
      memory_address_t tag;	//this is structure of lines
      int timestamp;
   } line_st;

   
   typedef struct
   {
      line_st *lines;	//pointer to an array of line, this is structure of set
   } cache_set;

   //Structure for a cache; a pointer to an array of sets

   typedef struct
   {
      cache_set *sets;	// A pointer to an array set, structure for a cache 
   } cache_t;

   //allocate some memory

   cache_t cache;

   cache.sets = malloc( par.S * sizeof ( cache_set ) );	// allocate some space for lines and sets
   for ( int i = 0; i < par.S; i++ )
   {
      cache.sets[i].lines = malloc( sizeof ( line_st ) * par.E );
   }

   //variables for counters

   int hit_count = 0;
   int miss_count = 0;
   int eviction_count = 0;

   // it is to  Run the trace cache simulation

   char act;                    //L,S,M
   int size;                    //size of file
   int TIMESTAMP = 0;              //value for LRU
   int empty = -1;              // empty space indexing
   int Hit = 0;                   //is to find  hit
   int EVI = 0;                   //is there an eviction
   memory_address_t addr;

   
   FILE *traceFile = fopen( trace_file, "r" ); //open the file and read the file

   if ( traceFile != NULL )
   {
      while ( fscanf( traceFile, " %c %llx,%d", &act, &addr, &size ) == 3 )	//scan the file
      {
         int toEvict = 0;             //track the trace file
         if ( act != 'I' )
         {
           
            memory_address_t addr_tag = addr >> ( par.s + par.b );// memory address indexing
            int tag_size = ( 64 - ( par.s + par.b ) );
            unsigned long long temp = addr << ( tag_size );
            unsigned long long setid = temp >> ( tag_size + par.b );
            cache_set set = cache.sets[setid];
            int low = INT_MAX; // Chage the limit

            for ( int e = 0; e < par.E; e++ ) {
               if ( set.lines[e].valid == 1 ) {
                  // hit change the order of the candidate
                  if ( set.lines[e].tag == addr_tag ) {
                     hit_count++;
                     Hit = 1;
                     set.lines[e].timestamp = TIMESTAMP;
                     TIMESTAMP++;
                  }
                  // CHANGED WHOLE ELSE: look for oldest for eviction.
                  else if ( set.lines[e].timestamp < low ) {
                     low = set.lines[e].timestamp;
                     toEvict = e;
                  }
               }
               // CHANGED: if we haven't yet found an empty, mark one that we found.
               else if( empty == -1 ) {
                  empty = e;
               }
            }

            //if we have a miss
            if ( Hit != 1 )
            {
               miss_count++; //miss count increment
               //find if we have an empty line
               if ( empty > -1 )
               {
                  set.lines[empty].valid = 1;
                  set.lines[empty].tag = addr_tag;
                  set.lines[empty].timestamp = TIMESTAMP;
                  TIMESTAMP++; 
               }
               //if the set is full we need to evict
               else if ( empty < 0 )
               {
                  EVI = 1;
                  set.lines[toEvict].tag = addr_tag;
                  set.lines[toEvict].timestamp = TIMESTAMP;
                  TIMESTAMP++; // timestamp increment
                  eviction_count++;
               }
            }
            //instruction set
            if ( act == 'M' )
            {
               hit_count++;
            }
            //is the set for verbosity
            if ( verbosity == 1 )
            {
               printf( "%c ", act );
               printf( "%llx,%d", addr, size );
               if ( Hit == 1 )
               {
                  printf( "Hit " );
               }
               else if ( Hit != 1 )		// check the no:of hits and miss and eviction
               {
                  printf( "Miss " );
               }
               if ( EVI == 1 )
               {
                  printf( "Eviction " );
               }
               //print the output of eviction
               printf( "\n" );
            }
            empty = -1;
            Hit = 0;
            EVI = 0;
         }
      }
   }

   //  Clean up cache the resources

   // GIVES THE  Print out real results
   printSummary( hit_count, miss_count, eviction_count ); // prints the required output
   return 0;
}
