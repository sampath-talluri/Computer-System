/*
 * Date: 03/04/2019
 * Class: CS5541
 * Assignment: Assignment 2
 * Author(s): Sampath Talluri
 */
commands:
 cache$ ./csim-ref
 cache$ ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace
 cache$ ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace
 
 cache$ gcc -std=c99 -Wall -o csim csim.c
 cache$ ./csim-ref -s 4 -E 1 -b 4 -t traces/yi.trace
 cache$ ./csim -s 1 -E 1 -b 1 -t traces/yi2.trace
cache$  ./csim -s 4 -E 2 -b 4 -t traces/yi.trace
cache$  ./csim -s 2 -E 1 -b 4 -t traces/dave.trace
cache$  ./csim -s 2 -E 1 -b 3 -t traces/trans.trace
cache$  ./csim -s 2 -E 2 -b 3 -t traces/trans.trace
cache$  ./csim -s 2 -E 4 -b 3 -t traces/trans.trace
cache$  ./csim -s 5 -E 1 -b 5 -t traces/trans.trace
 
./csim-ref -s 5 -E 1 -b 5 -t traces/long.trac
 Reference:
 1) https://github.com/theycallmeswift/Direct-Mapped-Cache-Simulation/blob/master/src/sim.c
 
 2) http://stackoverflow.com/questions/23092307/cache-simulator
 
 3) https://www.youtube.com/watch?v=BidkO8kqQts
 
 Warning:
 
	I did not get any warnings for this program. 

 Output:
                     Your simulator          Reference simulator
Points (s,E,b)    Hits  Misses  Evicts      Hits  Misses  Evicts
     3 (1,1,1)       9       8       6         9       8       6  traces/yi2.trace
     3 (4,2,4)       4       5       2         4       5       2  traces/yi.trace
     3 (2,1,4)       2       3       1         2       3       1  traces/dave.trace
     3 (2,1,3)     167      71      67       167      71      67  traces/trans.trace
     3 (2,2,3)     201      37      29       201      37      29  traces/trans.trace
     3 (2,4,3)     212      26      10       212      26      10  traces/trans.trace
     3 (5,1,5)     231       7       0       231       7       0  traces/trans.trace
     6 (5,1,5)  265189   21775   21743    265189   21775   21743  traces/long.trace
    27

TEST_CSIM_RESULTS=27
 
 