/*
 * FILE: memcheck.h
 *
 *       Interface to the memory leak checker.
 *
 */

#ifndef MEMCHECK_H
#define MEMCHECK_H

#include <stdlib.h>

void *check_malloc_function(size_t size, int L_number, char *filename);
void *check_calloc_function(size_t nmemb, size_t size,
                        char *filename, int L_number);
void  checked_free_fn(void *ptr, char *filename, int L_number);
void  memory_leak_prints(void);

/*
 * Macros which maintain the interface of the standard malloc/calloc/free
 * functions.  Don't include these if this file is being included into
 * memcheck.c, or it will screw up the definitions of the checked functions.
 */

#ifndef MEMCHECK_C

#define malloc(n)    check_malloc_function((n), __FILE__, __LINE__)
#define calloc(n, m) check_calloc_function((n), (m), __FILE__, __LINE__)
#define free(p)      check_free_function((p), __FILE__, __LINE__)

#endif  /* MEMCHECK_C */

#endif  /* MEMCHECK_H */

