/*
*Name: Sampath Talluri
*Assignment:Memory Allocation Lab
*Class:CS-5541
*/
/*
Reference(s):
http://courses.cms.caltech.edu/cs11/material/c/mike/misc/memcheck.c
http://condor.depaul.edu/glancast/374class/docs/malloc_steps.html


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MEMCHECK_C
#include "memcheck.h"

#define DEBUG 0

/*
 * Definition of data structure to keep memory allocation information.
 */

typedef
struct _memory_node
{
	size_t  n_byte;     /* Number of bytes allocated.                     */

	struct _memory_node *next_node;     /* Next node in linked list. */

	char   *filename;   /* Name of file where allocation occurred.        */

    	void *address;       /* Address of allocated memory.                   */

	int     L_number;     /* Line number of file where allocation occurred. */
   
}
memory_nodes;


/*
 * Function prototypes.
 */

void        allocate_memory_node(void *address, size_t n_byte, int L_number, char *filename);
void        free_memory_node(memory_nodes *n);
void        free_memory_node_and_adjust_pool(memory_nodes *n);
void        free_all_memory_nodes(void);
memory_nodes   *find_node(void *address);
void       *check_malloc_function(size_t size, int L_number, char *filename);
void       *check_calloc_function(size_t nmemb, size_t size,
                      char *filename, int L_number);
void        check_free_functionn(void *ptr, char *filename, int L_number);
void        memory_leak_prints(void);
void        dump(void);


/*
 * Initialize the memory pool linked list as a global variable.
 */

memory_nodes *pool = NULL;


/**********************************************************************
 *
 * Low-level functions for managing the memory pool linked list.
 *
 **********************************************************************/

/*
 * Allocate a memory node, set its values and link it into the memory
 * pool linked list.
 */

void
allocate_memory_node(void *address, size_t n_byte, int L_number, char *filename)
{
    memory_nodes *n;
    char *fn;

    /* Create the node and set its fields. */
    n = (memory_nodes *)malloc(sizeof(memory_nodes));

    if (n == NULL)
    {
        fprintf(stderr, "ERROR: memory allocation failed!  Aborting...\n");
        exit(1);
    }

#if DEBUG == 1
    fprintf(stderr, "Allocating %d bytes of memory at %p\n",
            n_byte, address);
#endif

    /* Copy the filename, which is statically allocated (I think). */
    fn = (char *)malloc((strlen(filename) + 1) * sizeof(char));
    strcpy(fn, filename);

    n->address = address;
    n->n_byte   = n_byte;
    n->filename = fn;
    n->L_number   = L_number;

    /* Add it to the front of the memory pool. */
    n->next_node = pool;
    pool    = n;
}


/*
 * Free a memory node from the pool.
 */

void
free_memory_node(memory_nodes *n)
{
    if (n != NULL)
    {
        if (n->address == NULL)
        {
            fprintf(stderr, "ERROR: invalid node at: %p\n", n->address);
            return;
        }

#if DEBUG == 1
        fprintf(stderr, "Freeing memory at %p\n", n->address);
#endif

        free(n->address);
        free(n->filename);
        free(n);
    }
}


/*
 * Free a memory node from the pool.  Adjust the 'next' pointer of the
 * previous node (if any) to skip over this node.
 */

void
free_memory_node_and_adjust_pool(memory_nodes *n)
{
    memory_nodes *p, *prev;

    prev = NULL;

    for (p = pool; p != NULL; p = p->next_node)
    {
        if (p->address == n->address)
        {
            if (prev == NULL)
            {
                /* The node to be removed is the first node. */
                pool = p->next_node;
                free_memory_node(p);
                break;   /* Nothing left to do. */
            }
            else
            {
                /*
                 * The node is in the interior of the memory pool
                 * linked list.  Adjust the 'next' pointer of the
                 * previous node and free the node.
                 */
                prev->next_node = p->next_node;
                free_memory_node(p);
                break;   /* Nothing left to do. */
            }
        }
        else
        {
            prev = p;
        }
    }
}


/*
 * Free all the memory nodes from the pool.
 */

void
free_all_memory_nodes(void)
{
   memory_nodes *n, *next_node;

    n = pool;

    while (n != NULL)
    {
        next_node = n->next_node;
        free_memory_node(n);
        n = next_node;
    }
}


/*
 * Return the node that corresponds to the address 'addr', or NULL if
 * the address isn't found.
 */

memory_nodes *
find_node(void *address)
{
    memory_nodes *n;

    for (n = pool; n != NULL; n = n->next_node)
    {
        if (n->address == address)
        {
            return n;
        }
    }

    return NULL;
}


/*
 * A debugging function to print the contents of the memory pool
 * linked list.
 */

void
dump(void)
{
    memory_nodes *n;

    for (n = pool; n != NULL; n = n->next_node)
    {
        fprintf(stderr, "NODE --------\n");
        fprintf(stderr, "location: %p\n", (void *)n);
        fprintf(stderr, "address: %p\n", n->address);
        fprintf(stderr, "n_byte: %d\n", (int)n->n_byte);
        fprintf(stderr, "filename: %s\n", n->filename);
        fprintf(stderr, "line number: %d\n", n->L_number);
        fprintf(stderr, "next: %p\n", (void *)n->next_node);
        fprintf(stderr, "\n");
    }
}


/**********************************************************************
 *
 * User-level functions.
 *
 * NOTE: Normally, the user will not use these functions, but will
 *       use 'malloc' and 'calloc' wrappers defined in "memcheck.h".
 *
 **********************************************************************/


/*
 * Allocate 'size' bytes of memory.  Also add the address, filename, and line
 * number as a new node in the memory pool linked list.
 */

void *
check_malloc_function(size_t size, int L_number, char *filename)
{
    void *mem;

    mem = malloc(size);

    if (mem == NULL)
    {
        fprintf(stderr, "ERROR: memory allocation failed!  Aborting...\n");
        exit(1);
    }

    allocate_memory_node(mem, size, filename, L_number);
    return mem;
}


/*
 * This function is the same as 'checked_malloc' except that it has
 * a different signature (corresponding to 'calloc' in the first two
 * arguments) and zeroes out all the allocated memory.
 */

void *
check_calloc_function(size_t nmemb, size_t size, char *filename, int L_number)
{
    void *mem;

    mem = calloc(nmemb, size);

    if (mem == NULL)
    {
        fprintf(stderr, "ERROR: memory allocation failed!  Aborting...\n");
        exit(1);
    }

    allocate_memory_node(mem, (nmemb * size), L_number, filename);
    return mem;
}


/*
 * Free a pointer that was previously allocated by 'checked_malloc()'.  If
 * the memory being freed is not found in the memory pool, print an error
 * message and abort.
 */

void
check_free_functionn(void *ptr, char *filename, int L_number)
{
    memory_nodes *n = find_node(ptr);

    if (n == NULL)
    {
        fprintf(stderr,
                "ERROR: invalid attempt to free unallocated memory at %p "
                "in file: %s, line: %d\n", ptr, filename, L_number);
        fprintf(stderr, "Aborting...\n");
        free_all_memory_nodes();
        exit(1);
    }
    else
    {
        free_memory_node_and_adjust_pool(n);
    }
}


/*
 * This function is intended to be called at the end of a program only.
 * It goes through the memory pool node-by-node and prints out information
 * on the contents of the node.  Any nodes that exist at the end of the
 * program represent leaked memory.
 */

void memory_leak_prints(void)
{
    memory_nodes *n;

    for (n = pool; n != NULL; n = n->next_node)
    {
        fprintf(stderr,
                "Memory leak: %d bytes allocated at %p in "
                "file: %s, line: %d.\n",
                (int)n->n_byte, n->address, n->filename, n->L_number);
    }

    free_all_memory_nodes();
}

