Date: 01/18/2019  
Class: CS5541  
Assignment: 1 Number Demonstration.
Name: Sampath Talluri

Command :

gcc assignment1.c -std=c99 -Wall
script
gcc assignment1.c -std=c99 -Wall
./a.out
exit


Reference :

https://www.w3schools.in
https://www.tutorialspoint.com/cprogramming/

E-Learning (Wmich)- cs5541 



OUTPUT :

svz8794@login01:~/Documents$ script
Script started, file is typescript
svz8794@login01:~/Documents$ gcc assignment1.c -std=c99 -Wall
assignment1.c: In function �problem5�:
assignment1.c:41:23: warning: integer overflow in expression [-Woverflow]
    assign_value =50000*50000;
                       ^
assignment1.c:44:23: warning: integer overflow in expression [-Woverflow]
    assign_value =60000*60000 ;
                       ^
svz8794@login01:~/Documents$ ./a.out
1. problem
2. problem
3. Problem
4. Problem
5. Problem
6. Problem
7. Exit
Select one of the case: 1

Output: 3.5999999046

Expected: 3.6000000000

Select one of the case: 2

Output:  0.1000000015

Expected: 3.6000000000

Select one of the case: 3

Output:
0.000000

0.500000

Expected:
0.5

0.5

Select one of the case: 4

Output:
9999999.450000
9999999.000000

Expected:
9999999.4499999999 

Select one of the case: 5

Output:
  900000000

  1600000000

  -1794967296

  -694967296

Expected: 
  900000000

  1600000000

  2500000000 

  3600000000
  

Select one of the case: 6

Output:
100000002004087734272.000000

100000002004087734272.000000

103500002601996386304.000000

100000002004087734272.000000

Expected: 
100000000000000000000
 
100000000003500000000

103500000000000000000
 
103500000000000000000



