#include <stdio.h>

void problem1()
{
float assign_value;
   assign_value = 3.6;
   printf("\n%.10f\n", assign_value);
}
void problem2()
{
   float assign_value;
   assign_value = 1.0/10.0;
   printf("\n%.10f\n", assign_value);
}
void problem3()
{
    double assign_value;
   assign_value = 1/2;
   printf("\n%f\n", assign_value);
  
   assign_value = 1.0/2.0;
   printf("\n%f\n", assign_value);
}
void problem4()
{
    double assign_value;
   assign_value = 9999999.4499999999;
   printf("\n%f\n", assign_value);
   float c_value = (float) assign_value;
   printf("\n%f", c_value);
}
void problem5()
{
    int assign_value;
   assign_value =30000*30000;
   printf("\n%d\n", assign_value);
  
   assign_value =40000*40000;
   printf("\n%d\n", assign_value);
  
   assign_value =50000*50000;
   printf("\n%d\n", assign_value);
  
   assign_value =60000*60000 ;
   printf("\n%d\n", assign_value);
}
void problem6()
{
    float assign_value;
   assign_value =1e20;
   printf("\n%f", assign_value);
  
   assign_value =(1e20 + 3500000000);
   printf("\n%f", assign_value);
  
   assign_value =(1e20 + (3500000000 * 1000000000));
   printf("\n%f", assign_value);
  

assign_value = 1e20;
int i;
for (i = 0; i < 1000000000 ; i++)
{
assign_value = assign_value + 3500000000;
}
printf("\n%f", assign_value);
}


	
int main()
{
    int value;

    printf( "1. problem\n" );
    printf( "2. problem\n" );
    printf( "3. Problem\n" );
    printf( "4. Problem\n" );
    printf( "5. Problem\n" );
    printf( "6. Problem\n" );
       printf( "7. Exit\n" );
    printf( "Select one of the case: " );
    scanf( "%d", &value );
    
    switch ( value ) {
        case 1:            
            problem1();/* calls problem 1 function */
            break;
        case 2:          
            problem2();/* calls problem 2 function */
            break;
        case 3:         
            problem3();/* calls problem 3 function */
            break;
        case 4:         
            problem4();/* calls problem 4 function */
            break;
        case 5:         
            problem5();/* calls problem 5 function */
            break;
        case 6:         
            problem6();
            break;/* calls problem 6 function */
        
        case 7:        
            printf( "\nExit" );
            break;
        
    }
    getchar();//getting the function

}