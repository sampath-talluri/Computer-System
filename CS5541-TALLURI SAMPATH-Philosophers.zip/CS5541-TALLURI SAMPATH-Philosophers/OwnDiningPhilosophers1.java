class PhilosopherState
{
	public String status[];
	public PhilosopherState()
	{
		status=new String[5];
		for(int i=0;i<5;i++)
 		{
  			//status[i]=new String();
			status[i]="thinking";
		}
	}
}

class Fork
{
}

class Philosopher extends Thread
{
	private Fork left,right;
	private String status;
	private int id;
	PhilosopherState state;

	public Philosopher(Fork left,Fork right,String name,int i,PhilosopherState state)
	{
		this.left=left;
		this.right=right;
		this.state=state;
		id=i;
		setName(name);
		start();
	}

	public void putDownLeftFork() throws InterruptedException
	{
		System.out.println(getName()+" put down left fork");
		//sleep(100);
	}

	public void putDownRightFork()throws InterruptedException
	{
		System.out.println(getName()+" put down right fork");
		//sleep(100);
	}

	public void pickUpLeftFork()throws InterruptedException
	{
		System.out.println(getName()+" pick up left fork");
		//sleep(100);
	}

	public void pickUpRightFork()throws InterruptedException
	{
		System.out.println(getName()+" pick up right fork");
		//sleep(100);
	}

	public void eat()throws InterruptedException
	{
		state.status[id]="eatting";
		System.out.println(getName()+" eatting ");
		//sleep(100);
	}

	public void thinking()throws InterruptedException
	{
		state.status[id]="thinking";
		System.out.println(getName()+"  thinking ");
		sleep(((int) (Math.random() * 100)));
		state.status[id]="hungry";
		System.out.println(getName()+"  hungry ");
	}

	public boolean test(int i)
	{

		if(!state.status[(i + 1) % 5] .equalsIgnoreCase( "eatting")&&! state.status[(i + 4) % 5] .equalsIgnoreCase( "eatting") && state.status[i].equalsIgnoreCase("hungry"))
		{
 			//Thread.currentThread().notify();
  			return true;
		} 
		else
		return false;
	}

	public void run()
	{
		try
		{
			while(true)
			{
				thinking();
				if(test(id))
				{
					synchronized(left)
					{
						pickUpLeftFork();
						synchronized(right)
						{
							pickUpRightFork();
							eat();
							putDownRightFork();
						}
					putDownLeftFork();
					}
				}
				else
				{
					//Thread.currentThread().wait();
					System.out.println(getName()+" waiting ");
				}


				//thinking();


			}
		}catch(Exception e)

		{
			System.out.println(getName()+" Interrupted ");
			//Thread.currentThread().interrupt();
			//return;
		}
	}//run closing


}

public class  OwnDiningPhilosophers1
{
	public static void main(String args[])
	{
  		final int size=5;
  		Philosopher []p=new Philosopher[size];
  		Fork []f=new Fork[size];
  		PhilosopherState state=new PhilosopherState();
  		for(int i=0;i<size;i++)
  		{
    			 f[i]=new Fork();
  		}

  		for(int i=0;i<size;i++)
 		{ 
    			p[i]=new Philosopher(f[i], f[(i+1)%size], "Philosopher_"+(i+1),i,state);
 		}  
 	}
}
