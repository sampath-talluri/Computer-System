class Fork
{
}

class Philosopher extends Thread
{
	 private Fork left,right;
 	public Philosopher(Fork left,Fork right,String name)
	{
 		this.left=left;
 		this.right=right;
		setName(name);
		start();
	}
	public void putDownLeftFork() throws InterruptedException
	{
		System.out.println(getName()+" put down left fork");
		sleep(100);
	}

	public void putDownRightFork()throws InterruptedException
	{
		System.out.println(getName()+" put down right fork");
		sleep(100);
	}

	public void pickUpLeftFork()throws InterruptedException
	{
		System.out.println(getName()+" pick up left fork");
		sleep(100);
	}

	public void pickUpRightFork()throws InterruptedException
	{
		System.out.println(getName()+" pick up right fork");
		sleep(100);
	}

	public void eat()throws InterruptedException
	{
		System.out.println(getName()+" eatting ");
		sleep(100);
	}

	public void thinking()throws InterruptedException
	{
		System.out.println(getName()+"  thinking ");
		sleep(100);
	}

	public void run()
	{
		try
		{
			while(true)
			{
				thinking();
				synchronized(left)
				{
					pickUpLeftFork();
					synchronized(right)
					{
						pickUpRightFork();
						eat();
						putDownRightFork();
					}
					putDownLeftFork();
				}

				//thinking();


			}
		}catch(Exception e)

		{
			System.out.println(getName()+" Interrupted ");
			Thread.currentThread().interrupt();
			return;
		}
	}//run closing
}

public class  OwnDiningPhilosophers
{
	public static void main(String args[])
	{
		final int size=5;
		Philosopher []p=new Philosopher[size];
		Fork []f=new Fork[size];

		for(int i=0;i<size;i++)
  		{
     			f[i]=new Fork();
  		}

 		for(int i=0;i<size;i++)
  		{ 
    			p[i]=new Philosopher(f[i], f[(i+1)%size], "Philosopher_"+(i+1));
  		}  
	}
}
