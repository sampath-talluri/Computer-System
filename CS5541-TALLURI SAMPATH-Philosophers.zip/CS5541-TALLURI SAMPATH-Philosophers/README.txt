/*
 * Date: 04/29/2019
 * Class: CS5541
 * Assignment: Dining Philosopher
 * Author(s): Sampath Talluri
 */

Commands:

	javac ownDiningphilosophers.java
	java ownDiningphilosophers

	javac ownDiningphilosophers1.java
	java ownDiningphilosophers1

	javac ownDiningphilosophers4.java
	java ownDiningphilosophers4


References:
1. https://gist.github.com/Alexey-N-Chernyshov/16198f75b284191bf2406d27eaad6b23
2. https://www.geeksforgeeks.org/dining-philosophers-solution-using-monitors/
3. https://github.com/clenk/School-Projects/blob/master/COS%20326/src/DiningPhilosophers.java
4. https://www.baeldung.com/java-dining-philoshophers
5. https://www.math.uni-hamburg.de/doc/java/tutorial/essential/threads/deadlock.html
6. https://www.geeksforgeeks.org/dining-philosophers-solution-using-monitors/






Others:

	OwnDiningPhilosophers3.java (Executes without semaphore)

	javac ownDiningphilosophers3.java
	java ownDiningphilosophers3