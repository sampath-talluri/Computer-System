import java.util.concurrent.*; 
class PhilosopherState			//setting the philosopher status for 5 philosophers
{
	public String status[];
	public PhilosopherState()
	{
		status=new String[5];
 		for(int i=0;i<5;i++)
 		{
  			//status[i]=new String();
  			status[i]="thinking";				//setting the status of each philosopher thinking initially
		}
	}
}

class Fork					//fork class that creats 5 fork objects
{
}

class Philosopher extends Thread			//Philosophers class that extends thread
{
 	private Fork left,right;
	private String status;
	private int id;
 	PhilosopherState state;
	Semaphore lock = new Semaphore(1);
	//Creating the semaphore object as mutex

 	public Philosopher(Fork left,Fork right,String name,int i,PhilosopherState state)
	{
 		this.left=left;			//creating the philosopher object philosopher id, state 
 		this.right=right;
 		this.state=state;
 		id=i;
		setName(name);			//setting the name for philosopher thread object
		start();				//starting the thread process
	}

	public void putDownLeftFork() throws InterruptedException
	{				//putdown the leftfork and waits random period of type
		System.out.println(getName()+" put down left fork");
		sleep(((int) (Math.random() * 500)));
	}

	public void putDownRightFork()throws InterruptedException
	{				//putdown the rightfork and waits random period of type
		System.out.println(getName()+" put down right fork");
		sleep(((int) (Math.random() * 500)));
	}

	public void pickUpLeftFork()throws InterruptedException
	{				//pickup left fork 
		System.out.println(getName()+" pick up left fork");
		sleep(((int) (Math.random() * 500)));
	}

	public void pickUpRightFork()throws InterruptedException
	{				//pickup right fork
		System.out.println(getName()+" pick up right fork");
		sleep(((int) (Math.random() * 500)));
	}

	public void eat()throws InterruptedException
	{				//philosopher eating method
		state.status[id]="eatting";
		System.out.println(getName()+" eatting ");
		sleep(((int) (Math.random() * 500)));
		System.out.println(getName()+" completed eatting ");
	}

	public void thinking()throws InterruptedException
	{				//after eating philosopher thinking
		state.status[id]="thinking";
 		System.out.println(getName()+"  thinking ");
		sleep(((int) (Math.random() * 500)));
	}

	public void hungry()throws InterruptedException
	{				//philosopher hungry method
		state.status[id]="hungry";
		System.out.println(getName()+"  hungry ");
		sleep(((int) (Math.random() * 500)));
	}

	public boolean test(int i)
	{				//testing the either sides of the philosopher eatting or not

		if(!state.status[(i + 1) % 5] .equalsIgnoreCase( "eatting")&&! state.status[(i + 4) % 5] .equalsIgnoreCase( "eatting") && state.status[i].equalsIgnoreCase("hungry"))
		{
			//Thread.currentThread().notify();
  			return true;			//if either sides of the philosopher not eatting then returns true
		} 
		else
 		return false;			//if any one of either side philosopher eatting then returns false
	}

	public void run()			//thread process that compiting for forks
	{
		try
		{
			while(true)
			{
				thinking();				//initially philosopher waiting
				hungry();				//after random period philosopher gets hungry
				if(test(id))				//tests either side of philosophers whether eatting or not
				{
					lock.acquire();			//if the philosopher not eatting then locks the process  to eat
					synchronized(left)
					{			//synchornizes the process
						pickUpLeftFork();			//picks up left fork
						synchronized(right)
						{
							pickUpRightFork();			//picks up right fork
							eat();				//eatting the food
							putDownRightFork();			//putdown the right fork
						}
						putDownLeftFork();			//putdown the left fork
					}							//releases the synchronization
					lock.release();			//releases the semaphore lock
				}
				else
				{
					//Thread.currentThread().wait();
					System.out.println(getName()+" waiting ");
			}


			//thinking();


		}
		}catch(Exception e)
		{
			System.out.println(getName()+" Interrupted ");
			//Thread.currentThread().interrupt();
			//return;
		}
	}//run closing

}

public class  OwnDiningPhilosophers4
{	public static void main(String args[])
	{
  		final int size=5;
  		Philosopher []p=new Philosopher[size];		//creating 5 philosopher object array
  		Fork []f=new Fork[size];			//creating 5 fork object array
 		PhilosopherState state=new PhilosopherState();
  		for(int i=0;i<size;i++)
  		{
     			f[i]=new Fork();				//creating 5 forks 
  		}
 		 for(int i=0;i<size;i++)
 		{ 					//creating 5 philosophers and activiting the threads
    			p[i]=new Philosopher(f[i], f[(i+1)%size], "Philosopher_"+(i+1),i,state);
		}  
 	}
}
