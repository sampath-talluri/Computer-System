Date: 01/10/2019  
Class: CS5541  
Assignment: simple c program  
Author(s): Sampath Talluri

Command :
gcc simpleprogram.c -std=c99 -Wall

Reference :

E-Learning (Wmich)- cs5541 