/*
Date: 01/10/2019  
Class: CS5541  
Assignment: Simpleprogram
Author(s): Sampath Talluri 
*/


#include<stdio.h>

int main()
{
  printf("Western Michigan University");
  printf("NAME: Sampath Talluri");
  
}
  